<?php

require_once(__DIR__."/../model/Usuario.php");
require_once(__DIR__."/../util/config.php");

class LoginService{

    public function validarLogin($login, $senha){

        $erros = array();

        if(! $login){
            array_push($erros, "Informe o Login!");

        }
        if(! $login){
            array_push($erros, "Informe a Senha!");

        }
        //adicionar erros se login e senha não estão preenchidos
        
        return $erros;

    }
    public function salvarUsuarioSessao(Usuario $usuario){

        session_start();
        $_SESSION[SESSAO_USUARIO_ID] = $usuario->getId();
        $_SESSION[SESSAO_USUARIO_NOME] = $usuario->getNome();

    }
}