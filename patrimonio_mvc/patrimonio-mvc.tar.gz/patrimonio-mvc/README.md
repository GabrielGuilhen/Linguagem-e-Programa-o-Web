# Sistema de Gerenciamento de Patrimônio Escolar

Sistema web desenvolvido em PHP para gerenciar bens móveis de escolas, seguindo o padrão arquitetural MVC (Model-View-Controller).

## 📋 Índice

- [Visão Geral](#visão-geral)
- [Arquitetura](#arquitetura)
- [Estrutura do Projeto](#estrutura-do-projeto)
- [Banco de Dados](#banco-de-dados)
- [Fluxo de Funcionamento](#fluxo-de-funcionamento)
- [Componentes Detalhados](#componentes-detalhados)
- [Instalação](#instalação)
- [Uso](#uso)

## 🎯 Visão Geral

O sistema permite o gerenciamento completo de bens móveis pertencentes a escolas municipais e estaduais. As principais funcionalidades incluem:

- **Cadastro** de novos bens móveis
- **Listagem** de todos os bens cadastrados
- **Edição** de informações dos bens
- **Exclusão** de bens
- **Transferência automática** para almoxarifado quando o estado do bem é "Péssimo"

## 🏗️ Arquitetura

O projeto segue rigorosamente o padrão **MVC (Model-View-Controller)** com camadas adicionais:

```
┌─────────────────┐
│      VIEW       │ ← Interface do usuário (HTML/PHP)
└─────────────────┘
         ↕
┌─────────────────┐
│   CONTROLLER    │ ← Lógica de controle de fluxo
└─────────────────┘
         ↕
┌─────────────────┐
│    SERVICE      │ ← Regras de negócio e validações
└─────────────────┘
         ↕
┌─────────────────┐
│      DAO        │ ← Acesso a dados (Data Access Object)
└─────────────────┘
         ↕
┌─────────────────┐
│     MODEL       │ ← Entidades e estrutura de dados
└─────────────────┘
```

## 📁 Estrutura do Projeto

```
patrimonio-mvc/
├── 📄 index.php                    # Ponto de entrada - redireciona para listagem
├── 📄 database.sql                 # Script de criação do banco de dados
├── 📁 controller/                  # Controladores (C do MVC)
│   └── 📄 BensMoveisController.php
├── 📁 dao/                         # Data Access Objects
│   ├── 📄 BensMoveisDAO.php
│   └── 📄 BensImoveisDAO.php
├── 📁 model/                       # Modelos de dados (M do MVC)
│   ├── 📄 BensMoveis.php
│   └── 📄 BensImoveis.php
├── 📁 service/                     # Camada de serviços/regras de negócio
│   ├── 📄 BensMoveisService.php
│   └── 📄 BensImoveisService.php
├── 📁 util/                        # Utilitários
│   ├── 📄 Conexao.php             # Singleton para conexão com BD
│   └── 📄 config.php              # Configurações do sistema
├── 📁 view/                        # Visões (V do MVC)
│   ├── 📁 bens_moveis/
│   │   ├── 📄 listar.php          # Listagem de bens
│   │   ├── 📄 inserir.php         # Formulário de cadastro
│   │   ├── 📄 alterar.php         # Formulário de edição
│   │   └── 📄 excluir.php         # Confirmação de exclusão
│   └── 📁 include/
│       ├── 📄 header.php          # Cabeçalho comum
│       └── 📄 footer.php          # Rodapé comum
└── 📁 img/                         # Imagens do sistema
    ├── 📄 btn_editar.png
    └── 📄 btn_excluir.png
```

## 🗄️ Banco de Dados

### Estrutura das Tabelas

#### 1. `bens_imoveis` (Dados fixos - 51 escolas)
```sql
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- nome_da_escola (VARCHAR(100))
- localizacao (VARCHAR(200))
- tamanho_em_m2 (INT)
```

#### 2. `bens_moveis` (CRUD principal)
```sql
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- nome_da_escola (VARCHAR(100))
- itens (VARCHAR(100))
- marca (VARCHAR(100))
- estado_do_bem (VARCHAR(50))
- data_de_aquisicao (DATE)
- id_bem_imovel (INT, FOREIGN KEY)
```

#### 3. `almoxarifado_bens_permanentes` (Transferências automáticas)
```sql
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- id_bem_movel (INT, FOREIGN KEY)
- justificativa (VARCHAR(200))
- data_transferencia (DATE)
```

## 🔄 Fluxo de Funcionamento

### 1. **Fluxo de Inicialização**
```
index.php → Redirecionamento → view/bens_moveis/listar.php
```

### 2. **Fluxo de Listagem**
```
listar.php → ServicoBensMoveis → AcessoBensMoveis → Banco de Dados
     ↓
Recupera dados → Mapeia para objetos BensMoveis → Exibe na view
```

### 3. **Fluxo de Inserção**
```
listar.php [botão "Adicionar"] → inserir.php
     ↓
ControladorBensMoveis::inserir() → ServicoBensImoveis::listar()
     ↓
Exibe formulário com lista de escolas
     ↓
[Submit] → ControladorBensMoveis::salvarInsercao()
     ↓
ServicoBensMoveis::salvar() → Validações → AcessoBensMoveis::inserir()
     ↓
Se estado = "Péssimo" → Inserção automática em almoxarifado
     ↓
Redirecionamento para listar.php
```

### 4. **Fluxo de Edição**
```
listar.php [botão "Editar"] → alterar.php?id=X
     ↓
ControladorBensMoveis::alterar() → ServicoBensMoveis::buscarPorId()
     ↓
Carrega dados do bem + lista de escolas
     ↓
Exibe formulário preenchido
     ↓
[Submit] → ControladorBensMoveis::salvarAlteracao()
     ↓
Validações → AcessoBensMoveis::atualizar() → listar.php
```

### 5. **Fluxo de Exclusão**
```
listar.php [botão "Excluir"] → excluir.php?id=X
     ↓
ControladorBensMoveis::excluir() → ServicoBensMoveis::buscarPorId()
     ↓
Exibe dados para confirmação
     ↓
[Confirmar] → ControladorBensMoveis::confirmarExclusao()
     ↓
AcessoBensMoveis::excluir() → listar.php
```

## 🧩 Componentes Detalhados

### **MODEL (Camada de Dados)**

#### `BensMoveis.php`
- **Responsabilidade**: Representar a entidade "Bem Móvel"
- **Atributos**: id, nomeDaEscola, itens, marca, estadoDoBem, dataDeAquisicao, idBemImovel
- **Métodos**: Getters e Setters para todos os atributos
- **Padrão**: Encapsulamento total com métodos de acesso

#### `BensImoveis.php`
- **Responsabilidade**: Representar a entidade "Bem Imóvel" (Escola)
- **Atributos**: id, nomeDaEscola, localizacao, tamanhoEmM2
- **Uso**: Referência para os bens móveis (relacionamento)

### **DAO (Data Access Object)**

#### `BensMoveisDAO.php` (AcessoBensMoveis)
- **Responsabilidade**: Gerenciar todas as operações de banco para bens móveis
- **Métodos principais**:
  - `inserir()`: Insere novo bem + transferência automática se estado = "Péssimo"
  - `atualizar()`: Atualiza bem existente
  - `excluir()`: Remove bem do banco
  - `listar()`: Retorna todos os bens ordenados por data de aquisição
  - `buscarPorId()`: Busca bem específico
  - `mapearBensMoveis()`: Converte array SQL em objetos BensMoveis

#### `BensImoveisDAO.php` (AcessoBensImoveis)
- **Responsabilidade**: Gerenciar operações de leitura dos bens imóveis
- **Métodos**:
  - `listar()`: Lista todas as escolas ordenadas por nome
  - `buscarPorId()`: Busca escola específica
  - `mapearBensImoveis()`: Converte array SQL em objetos BensImoveis

### **SERVICE (Regras de Negócio)**

#### `BensMoveisService.php` (ServicoBensMoveis)
- **Responsabilidade**: Implementar regras de negócio e validações
- **Métodos**:
  - `salvar()`: Coordena inserção/atualização com validações
  - `getErros()`: Valida todos os campos obrigatórios
  - `listar()`, `buscarPorId()`, `excluir()`: Delegam para DAO
- **Validações implementadas**:
  - Nome da escola obrigatório
  - Itens obrigatório
  - Marca obrigatória
  - Estado do bem obrigatório
  - Data de aquisição obrigatória
  - ID do bem imóvel obrigatório

#### `BensImoveisService.php` (ServicoBensImoveis)
- **Responsabilidade**: Fornecer serviços para bens imóveis
- **Métodos**: `listar()` e `buscarPorId()` (apenas leitura)

### **CONTROLLER (Controlador)**

#### `BensMoveisController.php` (ControladorBensMoveis)
- **Responsabilidade**: Controlar fluxo da aplicação e coordenar components
- **Propriedades**:
  - `$servicoBensMoveis`: Instância do serviço de bens móveis
  - `$servicoBensImoveis`: Instância do serviço de escolas
  - `$bensMoveis`, `$escolas`, `$erros`: Dados para as views
- **Métodos**:
  - `listar()`: Prepara dados e carrega view de listagem
  - `inserir()`: Prepara formulário de inserção
  - `alterar($id)`: Prepara formulário de edição
  - `excluir($id)`: Prepara confirmação de exclusão
  - `salvarInsercao()`: Processa inserção com validações
  - `salvarAlteracao()`: Processa edição com validações
  - `confirmarExclusao()`: Executa exclusão

### **VIEW (Interface)**

#### `listar.php`
- **Responsabilidade**: Exibir listagem de bens móveis
- **Funcionalidades**:
  - Processa ações POST (inserção, edição, exclusão)
  - Carrega dados via ServiçoBensMoveis
  - Exibe tabela com todos os bens
  - Botões de ação (Editar, Excluir, Adicionar)

#### `inserir.php`
- **Responsabilidade**: Formulário de cadastro
- **Características**:
  - Select box com lista de escolas
  - Campos para todos os atributos do bem
  - Validação client-side e server-side
  - Exibição de erros de validação

#### `alterar.php`
- **Responsabilidade**: Formulário de edição
- **Características**:
  - Formulário preenchido com dados existentes
  - Mesmo layout do inserir.php
  - Campo ID oculto para identificação

#### `excluir.php`
- **Responsabilidade**: Confirmação de exclusão
- **Características**:
  - Exibe dados do bem para confirmação
  - Botões "Confirmar" e "Cancelar"
  - Dados em modo somente leitura

### **UTIL (Utilitários)**

#### `Conexao.php`
- **Padrão**: Singleton
- **Responsabilidade**: Gerenciar conexão única com banco de dados
- **Características**:
  - Configuração de charset UTF-8
  - Tratamento de exceções PDO
  - Retorno como array associativo por padrão

#### `config.php`
- **Responsabilidade**: Centralizaar configurações do sistema
- **Configurações**:
  - Constantes de conexão com banco
  - Configurações de debug (display_errors)
  - Ambiente de desenvolvimento

## 🚀 Instalação

### Pré-requisitos
- PHP 7.4 ou superior
- MySQL/MariaDB
- Servidor web (Apache/Nginx)

### Passos

1. **Clone/baixe o projeto**
```bash
git clone [url-do-repositorio]
cd patrimonio-mvc
```

2. **Configure o banco de dados**
- Edite `util/config.php` com suas credenciais:
```php
define("DB_HOST", "localhost");
define("DB_NAME", "patrimonio_mvc_novo");
define("DB_USER", "seu_usuario");
define("DB_PASSWORD", "sua_senha");
```

3. **Crie o banco de dados**
```bash
mysql -u root -p < database.sql
```

4. **Configure o servidor web**
- Aponte o document root para a pasta do projeto
- Ou coloque na pasta htdocs/www do seu servidor

## 📖 Uso

### Acessar o Sistema
1. Abra o navegador e acesse: `http://localhost/patrimonio-mvc`
2. O sistema irá redirecionar automaticamente para a listagem de bens

### Operações Disponíveis

#### Adicionar Bem Móvel
1. Na listagem, clique em "Adicionar Novo Bem"
2. Preencha todos os campos obrigatórios
3. Selecione a escola na lista suspensa
4. Clique em "Salvar"

#### Editar Bem Móvel
1. Na listagem, clique no botão "Editar" do bem desejado
2. Modifique os campos necessários
3. Clique em "Salvar"

#### Excluir Bem Móvel
1. Na listagem, clique no botão "Excluir" do bem desejado
2. Confirme a exclusão na tela de confirmação
3. Clique em "Confirmar Exclusão"

### Funcionalidade Especial: Transferência Automática
Quando um bem móvel é cadastrado ou editado com estado "Péssimo", o sistema automaticamente:
1. Salva o bem na tabela `bens_moveis`
2. Cria um registro na tabela `almoxarifado_bens_permanentes`
3. Registra a data de transferência automática

## 🎯 Pontos-Chave da Arquitetura

### Separação de Responsabilidades
- **Model**: Apenas estrutura de dados, sem lógica
- **DAO**: Somente operações de banco de dados
- **Service**: Todas as regras de negócio e validações
- **Controller**: Coordenação entre camadas e controle de fluxo
- **View**: Apenas apresentação, sem lógica de negócio

### Padrões Utilizados
- **Singleton**: Classe Conexao para única instância de BD
- **DAO**: Abstração do acesso a dados
- **MVC**: Separação clara entre modelo, visão e controle
- **Service Layer**: Camada adicional para regras de negócio

### Vantagens da Arquitetura
1. **Manutenibilidade**: Código organizado e fácil de modificar
2. **Testabilidade**: Camadas isoladas facilitam testes unitários
3. **Reutilização**: Services e DAOs podem ser reutilizados
4. **Escalabilidade**: Fácil adição de novas funcionalidades
5. **Separação de Concerns**: Cada classe tem uma responsabilidade específica

---

## 📄 Licença

Este projeto é um exemplo educacional para demonstração do padrão MVC em PHP.
