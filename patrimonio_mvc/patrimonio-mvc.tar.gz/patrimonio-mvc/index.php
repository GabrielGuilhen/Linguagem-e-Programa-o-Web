<?php
// Redireciona para a listagem de bens moveis
header("location: ./view/bens_moveis/listar.php");
?>
