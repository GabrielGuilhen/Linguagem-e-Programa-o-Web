<?php

require_once(__DIR__ . "/../util/Conexao.php");
require_once(__DIR__ . "/../model/BensImoveis.php");

//Arquivo AcessoBensImoveis.php em dao
class AcessoBensImoveis {

    private $conn;

    public function __construct() {
        $this->conn = Conexao::getConexao();
    }

    public function listar() {
        $sql = "SELECT * FROM bens_imoveis ORDER BY nome_da_escola";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $this->mapearBensImoveis($result);
    }

    public function buscarPorId($id) {
        $sql = "SELECT * FROM bens_imoveis WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([$id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$result) {
            return null;
        }

        $bensImoveis = new BensImoveis(
            $result['id'],
            $result['nome_da_escola'],
            $result['localizacao'],
            $result['tamanho_em_m2']
        );

        return $bensImoveis;
    }

    private function mapearBensImoveis($resultSQL) {
        $bensImoveis = array();
        foreach ($resultSQL as $reg) {
            $bemImovel = new BensImoveis(
                $reg['id'],
                $reg['nome_da_escola'],
                $reg['localizacao'],
                $reg['tamanho_em_m2']
            );
            array_push($bensImoveis, $bemImovel);
        }
        return $bensImoveis;
    }
}
?>
