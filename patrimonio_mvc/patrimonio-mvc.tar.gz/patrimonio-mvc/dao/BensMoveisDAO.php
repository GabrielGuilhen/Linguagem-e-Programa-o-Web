<?php

require_once(__DIR__ . "/../util/Conexao.php");
require_once(__DIR__ . "/../model/BensMoveis.php");

//Arquivo AcessoBensMoveis.php em dao
class AcessoBensMoveis {

    private $conn;

    public function __construct() {
        $this->conn = Conexao::getConexao();
    }

    public function inserir(BensMoveis $bensMoveis) {
        $sql = "INSERT INTO bens_moveis (nome_da_escola, itens, marca, estado_do_bem, data_de_aquisicao, id_bem_imovel) 
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            $bensMoveis->getNomeDaEscola(),
            $bensMoveis->getItens(),
            $bensMoveis->getMarca(),
            $bensMoveis->getEstadoDoBem(),
            $bensMoveis->getDataDeAquisicao(),
            $bensMoveis->getIdBemImovel()
        ]);
        $id = $this->conn->lastInsertId();
        $bensMoveis->setId($id);
        return $bensMoveis;
    }

    public function atualizar(BensMoveis $bensMoveis) {
        $sql = "UPDATE bens_moveis SET nome_da_escola = ?, itens = ?, marca = ?, estado_do_bem = ?, data_de_aquisicao = ?, id_bem_imovel = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            $bensMoveis->getNomeDaEscola(),
            $bensMoveis->getItens(),
            $bensMoveis->getMarca(),
            $bensMoveis->getEstadoDoBem(),
            $bensMoveis->getDataDeAquisicao(),
            $bensMoveis->getIdBemImovel(),
            $bensMoveis->getId()
        ]);
    }

    public function excluir($id) {
        $sql = "DELETE FROM bens_moveis WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([$id]);
    }

    public function listar() {
        $sql = "SELECT * FROM bens_moveis ORDER BY data_de_aquisicao DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $this->mapearBensMoveis($result);
    }

    public function buscarPorId($id) {
        $sql = "SELECT * FROM bens_moveis WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([$id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$result) {
            return null;
        }

        $bensMoveis = new BensMoveis(
            $result['id'],
            $result['nome_da_escola'],
            $result['itens'],
            $result['marca'],
            $result['estado_do_bem'],
            $result['data_de_aquisicao'],
            $result['id_bem_imovel']
        );

        return $bensMoveis;
    }

    private function mapearBensMoveis($resultSQL) {
        $bensMoveis = array();
        foreach ($resultSQL as $reg) {
            $bemMovel = new BensMoveis(
                $reg['id'],
                $reg['nome_da_escola'],
                $reg['itens'],
                $reg['marca'],
                $reg['estado_do_bem'],
                $reg['data_de_aquisicao'],
                $reg['id_bem_imovel']
            );
            array_push($bensMoveis, $bemMovel);
        }
        return $bensMoveis;
    }
}
?>
