-- Criação do banco de dados
CREATE DATABASE IF NOT EXISTS patrimonio_mvc_novo;
USE patrimonio_mvc_novo;

-- Tabela bens_imoveis (dados fixos com 51 registros)
CREATE TABLE bens_imoveis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_da_escola VARCHAR(100) NOT NULL,
    localizacao VARCHAR(200) NOT NULL,
    tamanho_em_m2 INT NOT NULL
);

-- Inserção de 51 registros fictícios em bens_imoveis
INSERT INTO bens_imoveis (nome_da_escola, localizacao, tamanho_em_m2) VALUES
('Escola Municipal Cora Coralina', 'Rua das Rosas, 325 - Jardim das Flores', 1200),
('CMEI Pequeno Príncipe', 'Av. das Palmeiras, 150 - Vila A', 800),
('Escola Estadual João Paulo II', 'Rua das Acácias, 500 - Centro', 1500),
('Escola Municipal Santos Dumont', 'Av. das Orquídeas, 300 - Bairro Novo', 1000),
('CMEI Branca de Neve', 'Rua dos Ipês, 200 - Jardim Europa', 700),
('Escola Estadual Getúlio Vargas', 'Av. das Araucárias, 400 - Vila B', 1300),
('Escola Municipal Tiradentes', 'Rua das Magnólias, 600 - Jardim C', 1100),
('CMEI Chapeuzinho Vermelho', 'Av. dos Girassóis, 250 - Bairro D', 900),
('Escola Estadual Marechal Rondon', 'Rua das Hortênsias, 350 - Centro', 1400),
('Escola Municipal Anita Garibaldi', 'Av. das Azaleias, 450 - Vila E', 950),
('CMEI Peter Pan', 'Rua dos Jasmins, 180 - Jardim F', 750),
('Escola Estadual Tancredo Neves', 'Av. das Bromélias, 550 - Bairro G', 1250),
('Escola Municipal Zumbi dos Palmares', 'Rua das Violetas, 700 - Jardim H', 1050),
('CMEI Alice no País das Maravilhas', 'Av. dos Lírios, 300 - Vila I', 850),
('Escola Estadual Dom Pedro II', 'Rua das Margaridas, 400 - Centro', 1350),
('Escola Municipal José de Alencar', 'Av. das Begônias, 500 - Bairro J', 1150),
('CMEI Pinóquio', 'Rua dos Cravos, 220 - Jardim K', 800),
('Escola Estadual Rui Barbosa', 'Av. das Tulipas, 600 - Vila L', 1450),
('Escola Municipal Machado de Assis', 'Rua das Dálias, 350 - Bairro M', 1200),
('CMEI Cinderela', 'Av. dos Girassóis, 280 - Jardim N', 900),
('Escola Estadual Castelo Branco', 'Rua das Rosas, 450 - Centro', 1300),
('Escola Municipal Monteiro Lobato', 'Av. das Orquídeas, 550 - Vila O', 1100),
('CMEI João e Maria', 'Rua dos Ipês, 300 - Bairro P', 850),
('Escola Estadual Juscelino Kubitschek', 'Av. das Araucárias, 650 - Jardim Q', 1400),
('Escola Municipal Carlos Drummond de Andrade', 'Rua das Magnólias, 400 - Vila R', 1000),
('CMEI O Mágico de Oz', 'Av. dos Girassóis, 320 - Bairro S', 950),
('Escola Estadual Fernando Pessoa', 'Rua das Hortênsias, 500 - Centro', 1350),
('Escola Municipal Guimarães Rosa', 'Av. das Azaleias, 600 - Jardim T', 1150),
('CMEI A Bela Adormecida', 'Rua dos Jasmins, 250 - Vila U', 800),
('Escola Estadual Olavo Bilac', 'Av. das Bromélias, 700 - Bairro V', 1450),
('Escola Municipal Manuel Bandeira', 'Rua das Violetas, 450 - Jardim W', 1200),
('CMEI O Rei Leão', 'Av. dos Lírios, 350 - Vila X', 900),
('Escola Estadual Gonçalves Dias', 'Rua das Margaridas, 550 - Centro', 1300),
('Escola Municipal Cecília Meireles', 'Av. das Begônias, 650 - Bairro Y', 1100),
('CMEI Mogli', 'Rua dos Cravos, 300 - Jardim Z', 850),
('Escola Estadual Castro Alves', 'Av. das Tulipas, 400 - Vila AA', 1400),
('Escola Municipal Clarice Lispector', 'Rua das Dálias, 500 - Bairro AB', 1000),
('CMEI Simba', 'Av. dos Girassóis, 450 - Jardim AC', 950),
('Escola Estadual Vinicius de Moraes', 'Rua das Rosas, 600 - Centro', 1350),
('Escola Municipal João Cabral de Melo Neto', 'Av. das Orquídeas, 700 - Vila AD', 1150),
('CMEI Pumba', 'Rua dos Ipês, 350 - Bairro AE', 800),
('Escola Estadual Mário de Andrade', 'Av. das Araucárias, 450 - Jardim AF', 1450),
('Escola Municipal Lygia Fagundes Telles', 'Rua das Magnólias, 650 - Vila AG', 1200),
('CMEI Timão', 'Av. dos Girassóis, 500 - Bairro AH', 900),
('Escola Estadual Aluísio Azevedo', 'Rua das Hortênsias, 700 - Centro', 1300),
('Escola Municipal Graciliano Ramos', 'Av. das Azaleias, 550 - Jardim AI', 1100),
('CMEI Dumbo', 'Rua dos Jasmins, 400 - Vila AJ', 850),
('Escola Estadual Lima Barreto', 'Av. das Bromélias, 600 - Bairro AK', 1400),
('Escola Municipal Érico Veríssimo', 'Rua das Violetas, 550 - Jardim AL', 1000),
('CMEI Bambi', 'Av. dos Lírios, 450 - Vila AM', 950),
('Escola Estadual Jorge Amado', 'Rua das Margaridas, 650 - Centro', 1350),
('Escola Municipal Rachel de Queiroz', 'Av. das Begônias, 700 - Bairro AN', 1150);

-- Tabela bens_moveis (tabela do CRUD)
CREATE TABLE bens_moveis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_da_escola VARCHAR(100) NOT NULL,
    itens VARCHAR(100) NOT NULL,
    marca VARCHAR(100) NOT NULL,
    estado_do_bem VARCHAR(50) NOT NULL,
    data_de_aquisicao DATE NOT NULL,
    id_bem_imovel INT NOT NULL,
    FOREIGN KEY (id_bem_imovel) REFERENCES bens_imoveis(id)
);
