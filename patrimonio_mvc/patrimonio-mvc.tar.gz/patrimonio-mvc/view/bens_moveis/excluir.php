<?php
if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

require_once(__DIR__ . "/../../service/BensMoveisService.php");
$servicoBensMoveis = new ServicoBensMoveis();
$bensMoveis = $servicoBensMoveis->buscarPorId($_GET['id']);

include_once(__DIR__ . "/../include/header.php");
?>

<h2>Excluir Bem Móvel</h2>

<?php if (isset($bensMoveis)): ?>
<div class="alert alert-warning">
    <strong>Atenção!</strong> Você está prestes a excluir o seguinte bem móvel:
</div>

<div class="card">
    <div class="card-body">
        <h5 class="card-title"><?php echo htmlspecialchars($bensMoveis->getItens()); ?></h5>
        <p class="card-text">
            <strong>ID:</strong> <?php echo htmlspecialchars($bensMoveis->getId()); ?><br>
            <strong>Nome da Escola:</strong> <?php echo htmlspecialchars($bensMoveis->getNomeDaEscola()); ?><br>
            <strong>Marca:</strong> <?php echo htmlspecialchars($bensMoveis->getMarca()); ?><br>
            <strong>Estado do Bem:</strong> <?php echo htmlspecialchars($bensMoveis->getEstadoDoBem()); ?><br>
            <strong>Data de Aquisição:</strong> <?php echo htmlspecialchars($bensMoveis->getDataDeAquisicao()); ?>
        </p>
    </div>
</div>

<div class="mt-3">
    <form method="POST" action="listar.php" style="display: inline;">
        <input type="hidden" name="acao" value="confirmarExclusao">
        <input type="hidden" name="id" value="<?php echo $bensMoveis->getId(); ?>">
        <button type="submit" class="btn btn-danger" onclick="return confirm('Tem certeza que deseja excluir este bem móvel?')">
            Confirmar Exclusão
        </button>
    </form>
    <a href="listar.php" class="btn btn-secondary">Cancelar</a>
</div>
<?php else: ?>
<div class="alert alert-danger">
    Bem móvel não encontrado.
</div>
<a href="listar.php" class="btn btn-secondary">Voltar</a>
<?php endif; ?>

<?php
include_once(__DIR__ . "/../include/footer.php");
?>
