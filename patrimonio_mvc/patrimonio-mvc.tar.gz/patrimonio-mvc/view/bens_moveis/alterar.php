<?php
if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

require_once(__DIR__ . "/../../service/BensMoveisService.php");
require_once(__DIR__ . "/../../service/BensImoveisService.php");

$servicoBensMoveis = new ServicoBensMoveis();
$servicoBensImoveis = new ServicoBensImoveis();

$bensMoveis = $servicoBensMoveis->buscarPorId($_GET['id']);
$escolas = $servicoBensImoveis->listar();

include_once(__DIR__ . "/../include/header.php");
?>

<h2>Alterar Bem Móvel</h2>

<?php if (isset($erros) && count($erros) > 0): ?>
<div class="alert alert-danger">
    <ul class="mb-0">
        <?php foreach ($erros as $erro): ?>
        <li><?php echo htmlspecialchars($erro); ?></li>
        <?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>

<?php if (isset($bensMoveis)): ?>
<form method="POST" action="listar.php">
    <input type="hidden" name="acao" value="salvarAlteracao">
    <input type="hidden" name="id" value="<?php echo $bensMoveis->getId(); ?>">
    
    <div class="mb-3">
        <label for="nome_da_escola" class="form-label">Nome da Escola</label>
        <input type="text" class="form-control" id="nome_da_escola" name="nome_da_escola" 
               value="<?php echo htmlspecialchars($bensMoveis->getNomeDaEscola()); ?>" >
    </div>

    <div class="mb-3">
        <label for="itens" class="form-label">Itens</label>
        <input type="text" class="form-control" id="itens" name="itens" 
               value="<?php echo htmlspecialchars($bensMoveis->getItens()); ?>" >
    </div>

    <div class="mb-3">
        <label for="marca" class="form-label">Marca</label>
        <input type="text" class="form-control" id="marca" name="marca" 
               value="<?php echo htmlspecialchars($bensMoveis->getMarca()); ?>" >
    </div>

    <div class="mb-3">
        <label for="estado_do_bem" class="form-label">Estado do Bem</label>
        <select class="form-select" id="estado_do_bem" name="estado_do_bem" >
            <option value="">Selecione...</option>
            <option value="Novo" <?php echo ($bensMoveis->getEstadoDoBem() == 'Novo') ? 'selected' : ''; ?>>Novo</option>
            <option value="Usado" <?php echo ($bensMoveis->getEstadoDoBem() == 'Usado') ? 'selected' : ''; ?>>Usado</option>
            <option value="Danificado" <?php echo ($bensMoveis->getEstadoDoBem() == 'Danificado') ? 'selected' : ''; ?>>Danificado</option>
            <option value="Péssimo" <?php echo ($bensMoveis->getEstadoDoBem() == 'Péssimo') ? 'selected' : ''; ?>>Péssimo</option>
        </select>
    </div>

    <div class="mb-3">
        <label for="data_de_aquisicao" class="form-label">Data de Aquisição</label>
        <input type="date" class="form-control" id="data_de_aquisicao" name="data_de_aquisicao" 
               value="<?php echo htmlspecialchars($bensMoveis->getDataDeAquisicao()); ?>" >
    </div>

    <div class="mb-3">
        <label for="id_bem_imovel" class="form-label">Bem Imóvel</label>
        <select class="form-select" id="id_bem_imovel" name="id_bem_imovel" >
            <option value="">Selecione uma escola...</option>
            <?php if (isset($escolas)): 
                foreach ($escolas as $escola): ?>
            <option value="<?php echo $escola->getId(); ?>" 
                    <?php echo ($bensMoveis->getIdBemImovel() == $escola->getId()) ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($escola->getNomeDaEscola()); ?>
            </option>
            <?php endforeach; 
            endif; ?>
        </select>
    </div>

    <div class="mb-3">
        <button type="submit" class="btn btn-success">Salvar Alterações</button>
        <a href="listar.php" class="btn btn-secondary">Cancelar</a>
    </div>
</form>
<?php else: ?>
<div class="alert alert-danger">
    Bem móvel não encontrado.
</div>
<a href="listar.php" class="btn btn-secondary">Voltar</a>
<?php endif; ?>

<?php
include_once(__DIR__ . "/../include/footer.php");
?>
