<?php
// Processar ações POST antes de qualquer saída
if (isset($_POST['acao'])) {
    require_once(__DIR__ . "/../../controller/BensMoveisController.php");
    $ctrl = new ControladorBensMoveis();
    if ($_POST['acao'] == 'salvarInsercao') {
        $ctrl->salvarInsercao();
    } elseif ($_POST['acao'] == 'salvarAlteracao') {
        $ctrl->salvarAlteracao();
    } elseif ($_POST['acao'] == 'confirmarExclusao') {
        $ctrl->confirmarExclusao();
    }
    exit; // Para evitar loops
}

// Carregar dados para listagem
require_once(__DIR__ . "/../../service/BensMoveisService.php");
$servicoBensMoveis = new ServicoBensMoveis();
$bensMoveis = $servicoBensMoveis->listar();

include_once(__DIR__ . "/../include/header.php");
?>

<h2>Lista de Bens Móveis</h2>

<a href="inserir.php" class="btn btn-primary mb-3">Adicionar Novo Bem</a>

<?php if (isset($bensMoveis) && count($bensMoveis) > 0): ?>
<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome da Escola</th>
            <th>Itens</th>
            <th>Marca</th>
            <th>Estado do Bem</th>
            <th>Data de Aquisição</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($bensMoveis as $bemMovel): ?>
        <tr>
            <td><?php echo htmlspecialchars($bemMovel->getId()); ?></td>
            <td><?php echo htmlspecialchars($bemMovel->getNomeDaEscola()); ?></td>
            <td><?php echo htmlspecialchars($bemMovel->getItens()); ?></td>
            <td><?php echo htmlspecialchars($bemMovel->getMarca()); ?></td>
            <td><?php echo htmlspecialchars($bemMovel->getEstadoDoBem()); ?></td>
            <td><?php echo htmlspecialchars($bemMovel->getDataDeAquisicao()); ?></td>
            <td>
                <a href="alterar.php?id=<?php echo $bemMovel->getId(); ?>" class="btn btn-sm btn-warning">Editar</a>
                <a href="excluir.php?id=<?php echo $bemMovel->getId(); ?>" class="btn btn-sm btn-danger">Excluir</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php else: ?>
<div class="alert alert-info">
    Nenhum bem móvel cadastrado.
</div>
<?php endif; ?>

<?php
include_once(__DIR__ . "/../include/footer.php");
?>
