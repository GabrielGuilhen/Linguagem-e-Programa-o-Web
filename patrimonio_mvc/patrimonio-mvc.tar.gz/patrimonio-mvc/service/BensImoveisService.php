<?php

require_once(__DIR__ . "/../dao/BensImoveisDAO.php");

//Arquivo ServicoBensImoveis.php em service
class ServicoBensImoveis {

    private $acessoBensImoveis;

    public function __construct() {
        $this->acessoBensImoveis = new AcessoBensImoveis();
    }

    public function listar() {
        return $this->acessoBensImoveis->listar();
    }

    public function buscarPorId($id) {
        return $this->acessoBensImoveis->buscarPorId($id);
    }
}
?>
