<?php

require_once(__DIR__ . "/../dao/BensMoveisDAO.php");
require_once(__DIR__ . "/../service/BensImoveisService.php");

//Arquivo ServicoBensMoveis.php em service
class ServicoBensMoveis {

    private $acessoBensMoveis;
    private $servicoBensImoveis;

    public function __construct() {
        $this->acessoBensMoveis = new AcessoBensMoveis();
        $this->servicoBensImoveis = new ServicoBensImoveis();
    }

    public function listar() {
        return $this->acessoBensMoveis->listar();
    }

    public function buscarPorId($id) {
        return $this->acessoBensMoveis->buscarPorId($id);
    }

    public function salvar(BensMoveis $bensMoveis) {
        $erros = $this->getErros($bensMoveis);
        if ($erros) {
            return $erros;
        }

        if ($bensMoveis->getId()) {
            $this->acessoBensMoveis->atualizar($bensMoveis);
        } else {
            $this->acessoBensMoveis->inserir($bensMoveis);
        }
        return [];
    }

    public function excluir($id) {
        $this->acessoBensMoveis->excluir($id);
    }

    private function getErros($bensMoveis) {
        $erros = [];
        if(!$bensMoveis->getNomeDaEscola()) {
            $erros[] = "Campo nome da escola obrigatório";
        }
        if(!$bensMoveis->getItens()) {
            $erros[] = "Campo itens obrigatório";
        }
        if(!$bensMoveis->getMarca()) {
            $erros[] = "Campo marca obrigatório";
        }
        if(!$bensMoveis->getEstadoDoBem()) {
            $erros[] = "Campo estado do bem obrigatório";
        }
        if(!$bensMoveis->getDataDeAquisicao()) {
            $erros[] = "Campo data de aquisição obrigatório";
        }
        if(!$bensMoveis->getIdBemImovel()) {
            $erros[] = "Campo id do bem imóvel obrigatório";
        }
        return $erros;
    }
}
?>
