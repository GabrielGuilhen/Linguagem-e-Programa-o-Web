<?php

require_once(__DIR__ . "/../service/BensMoveisService.php");
require_once(__DIR__ . "/../service/BensImoveisService.php");
require_once(__DIR__ . "/../model/BensMoveis.php");

//Arquivo ControladorBensMoveis.php em controller
class ControladorBensMoveis {

    private $servicoBensMoveis;
    private $servicoBensImoveis;
    public $bensMoveis;
    public $escolas;
    public $erros;

    public function __construct() {
        $this->servicoBensMoveis = new ServicoBensMoveis();
        $this->servicoBensImoveis = new ServicoBensImoveis();
    }

    public function listar() {
        $bensMoveis = $this->servicoBensMoveis->listar();
        $this->bensMoveis = $bensMoveis;
        require __DIR__ . '/../view/bens_moveis/listar.php';
    }

    public function inserir() {
        $escolas = $this->servicoBensImoveis->listar();
        $this->escolas = $escolas;
        $erros = $this->erros;
        require __DIR__ . '/../view/bens_moveis/inserir.php';
    }

    public function alterar($id) {
        $bensMoveis = $this->servicoBensMoveis->buscarPorId($id);
        $escolas = $this->servicoBensImoveis->listar();
        $this->bensMoveis = $bensMoveis;
        $this->escolas = $escolas;
        $erros = $this->erros; 
        require __DIR__ . '/../view/bens_moveis/alterar.php';
    }

    public function excluir($id) {
        $bensMoveis = $this->servicoBensMoveis->buscarPorId($id);
        $this->bensMoveis = $bensMoveis;
        require __DIR__ . '/../view/bens_moveis/excluir.php';
    }

    public function salvarInsercao() {
        $bensMoveis = new BensMoveis(
            "",
            $_POST['nome_da_escola'],
            $_POST['itens'],
            $_POST['marca'],
            $_POST['estado_do_bem'],
            $_POST['data_de_aquisicao'],
            $_POST['id_bem_imovel']
        );

        $erros = $this->servicoBensMoveis->salvar($bensMoveis);
        if ($erros) {
            $this->erros = $erros;
            $this->inserir();
        } else {
            header("Location: ./listar.php");
            exit;
        }
    }

    public function salvarAlteracao() {
        
        $bensMoveis = new BensMoveis(
            $_POST['id'],
            $_POST['nome_da_escola'],
            $_POST['itens'],
            $_POST['marca'],
            $_POST['estado_do_bem'],
            $_POST['data_de_aquisicao'],
            $_POST['id_bem_imovel']
        );

        $erros = $this->servicoBensMoveis->salvar($bensMoveis);
        if ($erros) {
            $this->erros = $erros;
            $this->alterar($_POST['id']);
        } else {
            header("Location: ./listar.php");
            exit;
        }
    }

    public function confirmarExclusao() {
        $this->servicoBensMoveis->excluir($_POST['id']);
        header("Location: ./listar.php");
        exit;
    }
}
?>
