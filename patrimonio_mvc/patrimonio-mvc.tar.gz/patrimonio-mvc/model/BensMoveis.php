<?php

//Arquivo BensMoveis.php em model
class BensMoveis {

    private $id;
    private $nomeDaEscola;
    private $itens;
    private $marca;
    private $estadoDoBem;
    private $dataDeAquisicao;
    private $idBemImovel;

    public function __construct($id = "", $nomeDaEscola = "", $itens = "", $marca = "", $estadoDoBem = "", $dataDeAquisicao = "", $idBemImovel = "") {
        $this->id = $id;
        $this->nomeDaEscola = $nomeDaEscola;
        $this->itens = $itens;
        $this->marca = $marca;
        $this->estadoDoBem = $estadoDoBem;
        $this->dataDeAquisicao = $dataDeAquisicao;
        $this->idBemImovel = $idBemImovel;
    }

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getNomeDaEscola() {
        return $this->nomeDaEscola;
    }

    public function setNomeDaEscola($nomeDaEscola) {
        $this->nomeDaEscola = $nomeDaEscola;
    }

    public function getItens() {
        return $this->itens;
    }

    public function setItens($itens) {
        $this->itens = $itens;
    }

    public function getMarca() {
        return $this->marca;
    }

    public function setMarca($marca) {
        $this->marca = $marca;
    }

    public function getEstadoDoBem() {
        return $this->estadoDoBem;
    }

    public function setEstadoDoBem($estadoDoBem) {
        $this->estadoDoBem = $estadoDoBem;
    }

    public function getDataDeAquisicao() {
        return $this->dataDeAquisicao;
    }

    public function setDataDeAquisicao($dataDeAquisicao) {
        $this->dataDeAquisicao = $dataDeAquisicao;
    }

    public function getIdBemImovel() {
        return $this->idBemImovel;
    }

    public function setIdBemImovel($idBemImovel) {
        $this->idBemImovel = $idBemImovel;
    }
}
?>
