<?php

//Arquivo BensImoveis.php em model
class BensImoveis {

    private $id;
    private $nomeDaEscola;
    private $localizacao;
    private $tamanhoEmM2;

    public function __construct($id = "", $nomeDaEscola = "", $localizacao = "", $tamanhoEmM2 = "") {
        $this->id = $id;
        $this->nomeDaEscola = $nomeDaEscola;
        $this->localizacao = $localizacao;
        $this->tamanhoEmM2 = $tamanhoEmM2;
    }

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getNomeDaEscola() {
        return $this->nomeDaEscola;
    }

    public function setNomeDaEscola($nomeDaEscola) {
        $this->nomeDaEscola = $nomeDaEscola;
    }

    public function getLocalizacao() {
        return $this->localizacao;
    }

    public function setLocalizacao($localizacao) {
        $this->localizacao = $localizacao;
    }

    public function getTamanhoEmM2() {
        return $this->tamanhoEmM2;
    }

    public function setTamanhoEmM2($tamanhoEmM2) {
        $this->tamanhoEmM2 = $tamanhoEmM2;
    }
}
?>
